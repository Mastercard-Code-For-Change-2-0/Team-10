# Project Skeleton

This archive mirrors the folder structure with exactly one file per folder (or .gitkeep as placeholder). Use it as a lightweight starting point for teammates.

Notes:
- Heavy folders like node_modules, build, logs, and env files are excluded.
- Add real files as you progress; keep structure intact.
