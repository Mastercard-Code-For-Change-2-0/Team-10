# Team Kits

Lightweight handoff packs for each role. Each folder contains:
- One tiny placeholder code file (hello.js)
- Directory structure preserved via .gitkeep files (no heavy code)

How to use:
- Assign a role kit to each teammate.
- They can copy relevant files from the main repo into this structure later, or work here and PR back.

Role kits included: FE1, FE2, BE1, BE2, DB1, DB2, BA1, BA2.
