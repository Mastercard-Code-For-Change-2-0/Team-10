console.log('FE2 ready');
