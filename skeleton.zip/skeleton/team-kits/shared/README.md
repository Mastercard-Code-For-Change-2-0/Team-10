# Shared Kit

Small shared assets used by multiple roles. Keep minimal.
